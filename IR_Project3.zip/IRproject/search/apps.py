from django.apps import AppConfig
from .query import search_engine

a=100
search = search_engine()
class SearchConfig(AppConfig):
    name = 'search'
    #def ready(self):
    #    print(a)